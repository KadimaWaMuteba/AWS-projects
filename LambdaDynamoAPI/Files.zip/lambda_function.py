import json
import boto3
import logging

# Initialize DynamoDB client
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('MyData')

# Set up logging
logging.basicConfig(level=logging.INFO)

def read_file(file_name):
    with open(file_name, 'r') as file:
        return file.read()

def lambda_handler(event, context):
    logging.info("Event: %s", event)  # Log the incoming event
    http_method = event.get('httpMethod', '')

    if http_method == 'GET':
        form_html = read_file('Form.html')
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'text/html'
            },
            'body': form_html
        }
        
    elif http_method == 'POST':
        # Get the data from the request body
        try:
            body = json.loads(event['body'])
            name = body.get('name', '')
            last_name = body.get('lastName', '')

            # Validate that name is provided
            if not name:
                return {
                    'statusCode': 400,
                    'body': json.dumps({'message': 'Name is required'})
                }

            # Store the data in DynamoDB
            table.put_item(Item={
                'name': name,           # Use 'Name' as the partition key
                'LastName': last_name   # Store last name
            })

        except Exception as e:
            logging.error("Error saving to DynamoDB: %s", str(e))
            return {
                'statusCode': 500,
                'body': json.dumps({'message': 'Failed to save data', 'error': str(e)})
            }

        registered_html = read_file('Registered.html')
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'text/html'
            },
            'body': registered_html
        }
        
    else:
        return {
            'statusCode': 400,
            'body': json.dumps({'message': 'Unsupported method'})
        }